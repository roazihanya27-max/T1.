# 🚀 Guía Rápida - API de Cobros Simulados

## 5 Minutos para Empezar

### Opción 1: Docker (Más Rápido ⭐)

```powershell
# 1. Entra a la carpeta del proyecto
cd "E:\Proyecto T1"

# 2. Levanta todo con Docker
docker-compose up

# 3. Abre tu navegador en:
# http://localhost:8000/docs
```

¡Listo! La API está corriendo. Puedes empezar a probarla en Swagger UI.

---

### Opción 2: Sin Docker (Manual)

```powershell
# 1. Entra a la carpeta
cd "E:\Proyecto T1"

# 2. Ejecuta el script de instalación
install.bat

# 3. Activa el entorno virtual manualmente si es necesario:
venv\Scripts\Activate.ps1

# 4. Asegúrate que MongoDB está corriendo en puerto 27017
# Si no tienes MongoDB, usa Docker:
docker run -d -p 27017:27017 mongo:7.0

# 5. Ejecuta la API
uvicorn app.main:app --reload

# 6. Abre en navegador:
# http://localhost:8000/docs
```

---

## Primeros Tests

### Test 1: Crear un Cliente

En Swagger UI (`http://localhost:8000/docs`):

1. Busca **POST /clientes/**
2. Click en "Try it out"
3. Rellena:
   ```json
   {
     "nombre": "Juan Pérez",
     "email": "juan@example.com",
     "telefono": "3001234567"
   }
   ```
4. Click "Execute"

**Resultado esperado:** Código 200 con datos del cliente creado ✅

---

### Test 2: Registrar una Tarjeta de Prueba

1. Copia el `id` del cliente del resultado anterior
2. Busca **POST /tarjetas/**
3. Click "Try it out"
4. Rellena:
   ```json
   {
     "cliente_id": "PEGA_EL_ID_DEL_CLIENTE_AQUI",
     "pan": "4532015112830366"
   }
   ```
5. Click "Execute"

**Resultado esperado:** Código 200 con `pan_masked` = `************0366` ✅

---

### Test 3: Realizar un Cobro

1. Copia el `id` de la tarjeta del resultado anterior
2. Busca **POST /cobros/**
3. Click "Try it out"
4. Rellena:
   ```json
   {
     "cliente_id": "PEGA_EL_ID_DEL_CLIENTE",
     "tarjeta_id": "PEGA_EL_ID_DE_LA_TARJETA",
     "monto": 150.50
   }
   ```
5. Click "Execute"

**Resultado esperado:** Código 200 con `status: "approved"` ✅

---

### Test 4: Reembolsar

1. Copia el `id` del cobro del resultado anterior
2. Busca **POST /cobros/{cobro_id}/reembolso**
3. Click "Try it out"
4. Pega el ID del cobro
5. Rellena:
   ```json
   {
     "motivo": "Cambio de opinión"
   }
   ```
6. Click "Execute"

**Resultado esperado:** Código 200 con `reembolsado: true` ✅

---

## Tarjetas de Prueba

### Tarjetas Válidas (Siempre Aprobadas)

| Tipo | PAN | Last4 | BIN |
|------|-----|-------|-----|
| Visa | 4532015112830366 | 0366 | 453201 |
| Mastercard | 5425233010103442 | 3442 | 542523 |
| American Express | 378282246310005 | 0005 | 378282 |

✅ Todas estas tarjetas serán **APROBADAS**

### Tarjeta Rechazada

Para probar rechazos, usa cualquier tarjeta cuyo `last4` sea `0000`. La API rechazará automáticamente.

---

## Endpoints Principales

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/clientes/` | Crear cliente |
| GET | `/clientes/{id}` | Obtener cliente |
| PUT | `/clientes/{id}` | Actualizar cliente |
| DELETE | `/clientes/{id}` | Eliminar cliente |
| POST | `/tarjetas/` | Registrar tarjeta |
| GET | `/tarjetas/{id}` | Obtener tarjeta |
| POST | `/cobros/` | Realizar cobro |
| GET | `/cobros/{cliente_id}` | Historial de cobros |
| POST | `/cobros/{cobro_id}/reembolso` | Reembolsar |

---

## Documentación

- 📖 **README.md** - Documentación completa
- 🏠 **INSTALACION.md** - Instrucciones detalladas de instalación
- 💳 **docs/TEST_CARDS.md** - Tarjetas de prueba documentadas
- 📮 **docs/Postman_Collection.json** - Para importar en Postman

---

## Validación Luhn

La API valida TODOS los números de tarjeta con el algoritmo Luhn.

✅ Las tarjetas de prueba documentadas son todas válidas.

Si intentas registrar una tarjeta inválida (ej. con un dígito cambiado), recibirás error 400 con mensaje: "Número de tarjeta no es válido (validación Luhn fallida)"

---

## Reglas de Aprobación/Rechazo

### ✅ APROBADO si:
- La tarjeta es válida (Luhn OK)
- El `last4` ≠ 0000
- El cliente existe

### ❌ RECHAZADO si:
- El `last4` = 0000
- La tarjeta no existe

---

## Base de Datos

MongoDB se crea automáticamente con 3 colecciones:
- `clientes` - Datos de clientes
- `tarjetas` - Tarjetas registradas (PAN enmascarado)
- `cobros` - Historial de transacciones

**⚠️ SEGURIDAD:** Los números completos de tarjeta NUNCA se almacenan. Solo se guardan los últimos 4 dígitos y el BIN.

---

## Troubleshooting Rápido

| Problema | Solución |
|----------|----------|
| **"Connection refused"** | MongoDB no corre. Usa: `docker run -d -p 27017:27017 mongo:7.0` |
| **"Port 8000 in use"** | Otro programa usa el puerto. Usa: `uvicorn app.main:app --port 8001` |
| **"Module not found"** | Instala dependencias: `pip install -r requirements.txt` |
| **"Luhn validation failed"** | El número de tarjeta es inválido. Usa los ejemplos documentados. |

---

## Ejecutar Tests

```powershell
# Todos los tests
pytest

# Solo tests de Luhn
pytest tests/test_luhn.py -v

# Con cobertura
pytest --cov=app tests/
```

---

## Links Útiles

| Recurso | URL |
|---------|-----|
| Swagger UI | http://localhost:8000/docs |
| ReDoc | http://localhost:8000/redoc |
| Health Check | http://localhost:8000/ |

---

## Próximos Pasos

1. ✅ Levanta la API (Docker o manual)
2. ✅ Abre Swagger UI
3. ✅ Crea un cliente
4. ✅ Registra una tarjeta
5. ✅ Realiza un cobro
6. ✅ Consulta el historial
7. ✅ Reembolsa

¡Listo! Ya sabes cómo usar la API.

---

**Última actualización:** 2026-02-10  
**Versión:** 1.0.0
