#!/bin/bash

# Script para instalar el proyecto en Linux/Mac
# Ejecutar: bash install.sh

echo "====================================="
echo "Instalación - API de Cobros T1"
echo "====================================="
echo ""

# Verificar que Python está instalado
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 no está instalado"
    echo "Por favor instala Python 3.11+"
    exit 1
fi

echo "[1/4] Creando entorno virtual..."
python3 -m venv venv

echo "[2/4] Activando entorno virtual..."
source venv/bin/activate

echo "[3/4] Instalando dependencias..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[4/4] Creando archivo .env..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "Creado: .env"
else
    echo "Ya existe: .env"
fi

echo ""
echo "====================================="
echo "Instalación completada!"
echo "====================================="
echo ""
echo "Instrucciones siguientes:"
echo "1. Asegúrate que MongoDB está corriendo (o usa Docker)"
echo "2. Ejecuta: uvicorn app.main:app --reload"
echo "3. Abre: http://localhost:8000/docs"
echo ""
echo "Para instalar MongoDB con Docker, ejecuta:"
echo "docker run -d -p 27017:27017 --name cobros-mongo mongo:7.0"
echo ""
