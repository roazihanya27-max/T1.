#!/bin/bash

# Script de ejemplo para probar la API
# Uso: bash examples.sh

API_URL="http://localhost:8000"

echo "=== API de Cobros Simulados - Ejemplos ==="
echo ""

# 1. Crear Cliente
echo "1. Creando cliente..."
CLIENTE_RESPONSE=$(curl -s -X POST $API_URL/clientes/ \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "telefono": "3001234567"
  }')

echo $CLIENTE_RESPONSE | jq .
CLIENTE_ID=$(echo $CLIENTE_RESPONSE | jq -r '.id')
echo "Cliente ID: $CLIENTE_ID"
echo ""

# 2. Registrar Tarjeta
echo "2. Registrando tarjeta..."
TARJETA_RESPONSE=$(curl -s -X POST $API_URL/tarjetas/ \
  -H "Content-Type: application/json" \
  -d "{
    \"cliente_id\": \"$CLIENTE_ID\",
    \"pan\": \"4532015112830366\"
  }")

echo $TARJETA_RESPONSE | jq .
TARJETA_ID=$(echo $TARJETA_RESPONSE | jq -r '.id')
echo "Tarjeta ID: $TARJETA_ID"
echo ""

# 3. Realizar Cobro
echo "3. Realizando cobro..."
COBRO_RESPONSE=$(curl -s -X POST $API_URL/cobros/ \
  -H "Content-Type: application/json" \
  -d "{
    \"cliente_id\": \"$CLIENTE_ID\",
    \"tarjeta_id\": \"$TARJETA_ID\",
    \"monto\": 150.50
  }")

echo $COBRO_RESPONSE | jq .
COBRO_ID=$(echo $COBRO_RESPONSE | jq -r '.id')
echo "Cobro ID: $COBRO_ID"
echo ""

# 4. Obtener Historial
echo "4. Obteniendo historial de cobros..."
curl -s -X GET $API_URL/cobros/$CLIENTE_ID | jq .
echo ""

# 5. Reembolsar
echo "5. Reembolsando cobro..."
curl -s -X POST $API_URL/cobros/$COBRO_ID/reembolso \
  -H "Content-Type: application/json" \
  -d '{"motivo": "Cambio de opinión"}' | jq .
echo ""

echo "=== Ejemplos completados ==="
