"""
Tests unitarios para la validación Luhn y funcionalidades de la API.
"""

import pytest
from app.luhn import (
    validate_luhn,
    generate_card_number,
    mask_card,
    get_last_four,
    get_bin
)


class TestLuhnValidation:
    """Tests para validación Luhn"""
    
    def test_valid_luhn(self):
        """Validar números válidos"""
        # Números de tarjeta válidos de prueba
        assert validate_luhn("4532015112830366") == True
        assert validate_luhn("5425233010103442") == True
        assert validate_luhn("378282246310005") == True
    
    def test_invalid_luhn(self):
        """Rechazar números inválidos"""
        assert validate_luhn("1234567890123456") == False
        assert validate_luhn("0000000000000000") == False
        assert validate_luhn("") == False
        assert validate_luhn("abcd") == False
    
    def test_luhn_with_spaces(self):
        """Manejar números con espacios"""
        assert validate_luhn("4532 0151 1283 0366") == False  # Sin procesar espacios
        
    def test_luhn_too_short(self):
        """Rechazar números muy cortos"""
        assert validate_luhn("123") == False
        assert validate_luhn("123456") == False


class TestCardGeneration:
    """Tests para generación de tarjetas"""
    
    def test_generate_valid_card(self):
        """Generar tarjeta válida con Luhn"""
        card = generate_card_number()
        assert len(card) == 16
        assert card.isdigit()
        assert validate_luhn(card) == True
    
    def test_generate_card_with_bin(self):
        """Generar tarjeta con BIN específico"""
        card = generate_card_number(bin_prefix="5555", length=16)
        assert card.startswith("5555")
        assert validate_luhn(card) == True
    
    def test_generate_multiple_cards_unique(self):
        """Generar múltiples tarjetas diferentes"""
        cards = [generate_card_number() for _ in range(5)]
        # Todas deben ser únicas (en teoría, hay probabilidad mínima de duplicado)
        assert len(set(cards)) == 5
        # Todas deben ser válidas
        assert all(validate_luhn(card) for card in cards)


class TestCardMasking:
    """Tests para enmascaramiento de tarjetas"""
    
    def test_mask_card(self):
        """Enmascarar tarjeta mostrando últimos 4 dígitos"""
        card = "4532015112830366"
        masked = mask_card(card)
        assert masked == "************0366"
        assert masked.endswith("0366")
        assert masked.count("*") == 12
    
    def test_get_last_four(self):
        """Obtener últimos 4 dígitos"""
        card = "4532015112830366"
        last4 = get_last_four(card)
        assert last4 == "0366"
    
    def test_get_bin(self):
        """Obtener BIN de 6 dígitos"""
        card = "4532015112830366"
        bin_code = get_bin(card)
        assert bin_code == "453201"
        assert len(bin_code) == 6
    
    def test_get_bin_custom_length(self):
        """Obtener BIN con longitud personalizada"""
        card = "4532015112830366"
        bin_code = get_bin(card, length=4)
        assert bin_code == "4532"


class TestCardNumbers:
    """Tests para números de tarjeta específicos"""
    
    def test_visa_pattern(self):
        """Validar patrón de tarjeta Visa"""
        # Las tarjetas Visa comienzan con 4
        card = generate_card_number(bin_prefix="4242")
        assert card.startswith("4242")
        assert validate_luhn(card) == True
    
    def test_mastercard_pattern(self):
        """Validar patrón de tarjeta Mastercard"""
        # Las tarjetas Mastercard comienzan con 5
        card = generate_card_number(bin_prefix="5555")
        assert card.startswith("5555")
        assert validate_luhn(card) == True


# Test cards específicas documentadas
TEST_CARDS = {
    "approved_visa": {
        "number": "4532015112830366",
        "last4": "0366",
        "bin": "453201",
        "expected_status": "approved",
        "description": "Visa válida - Aprobada"
    },
    "declined_card": {
        "number": "6011000990139424",
        "last4": "9424",
        "bin": "601100",
        "expected_status": "declined",
        "description": "Discover - Puede ser rechazada según reglas"
    },
    "amex": {
        "number": "378282246310005",
        "last4": "0005",
        "bin": "378282",
        "expected_status": "approved",
        "description": "American Express válida - Aprobada"
    }
}


def test_test_card_validation():
    """Validar que las tarjetas de prueba sean válidas con Luhn"""
    for card_type, card_info in TEST_CARDS.items():
        assert validate_luhn(card_info["number"]) == True, f"Tarjeta {card_type} inválida"
        assert get_last_four(card_info["number"]) == card_info["last4"]
        assert get_bin(card_info["number"]) == card_info["bin"]
