"""
Configuración de pytest para tests async.
"""

import pytest
import asyncio
from motor.motor_asyncio import AsyncClient
from app.database import db, connect_to_mongo, close_mongo_connection
from app.config import settings


@pytest.fixture(scope="session")
def event_loop():
    """Crear event loop para tests async"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session", autouse=True)
async def setup_database():
    """Setup y teardown de base de datos para tests"""
    # Usar base de datos de test
    await connect_to_mongo()
    
    # Limpiar colecciones antes de tests
    await db.clientes.delete_many({})
    await db.tarjetas.delete_many({})
    await db.cobros.delete_many({})
    
    yield
    
    # Limpiar después de tests
    await db.clientes.delete_many({})
    await db.tarjetas.delete_many({})
    await db.cobros.delete_many({})
    
    await close_mongo_connection()
