"""
Tests de integración para los endpoints de la API.
"""

import pytest
from httpx import AsyncClient
from app.main import app


@pytest.mark.asyncio
async def test_health_check():
    """Test del endpoint raíz"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"


# Tests para CRUD de Clientes
@pytest.mark.asyncio
async def test_crear_cliente():
    """Test crear cliente"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        cliente_data = {
            "nombre": "Juan Pérez",
            "email": "juan@example.com",
            "telefono": "3001234567"
        }
        response = await client.post("/clientes/", json=cliente_data)
        assert response.status_code == 200
        data = response.json()
        assert data["nombre"] == "Juan Pérez"
        assert data["email"] == "juan@example.com"


@pytest.mark.asyncio
async def test_obtener_cliente():
    """Test obtener cliente por ID"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Primero crear un cliente
        cliente_data = {
            "nombre": "María García",
            "email": "maria@example.com",
            "telefono": "3009876543"
        }
        create_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = create_response.json()["id"]
        
        # Luego obtenerlo
        response = await client.get(f"/clientes/{cliente_id}")
        assert response.status_code == 200
        assert response.json()["nombre"] == "María García"


@pytest.mark.asyncio
async def test_actualizar_cliente():
    """Test actualizar cliente"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Crear cliente
        cliente_data = {
            "nombre": "Carlos López",
            "email": "carlos@example.com",
            "telefono": "3005551234"
        }
        create_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = create_response.json()["id"]
        
        # Actualizar
        update_data = {
            "nombre": "Carlos López Actualizado"
        }
        response = await client.put(f"/clientes/{cliente_id}", json=update_data)
        assert response.status_code == 200
        assert response.json()["nombre"] == "Carlos López Actualizado"


@pytest.mark.asyncio
async def test_eliminar_cliente():
    """Test eliminar cliente"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Crear cliente
        cliente_data = {
            "nombre": "Ana Rodríguez",
            "email": "ana@example.com",
            "telefono": "3007779999"
        }
        create_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = create_response.json()["id"]
        
        # Eliminar
        response = await client.delete(f"/clientes/{cliente_id}")
        assert response.status_code == 204
        
        # Verificar que fue eliminado
        get_response = await client.get(f"/clientes/{cliente_id}")
        assert get_response.status_code == 404


# Tests para CRUD de Tarjetas
@pytest.mark.asyncio
async def test_crear_tarjeta():
    """Test crear tarjeta con validación Luhn"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Crear cliente primero
        cliente_data = {
            "nombre": "Cliente para Tarjeta",
            "email": "tarjeta@example.com",
            "telefono": "3001111111"
        }
        cliente_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = cliente_response.json()["id"]
        
        # Crear tarjeta válida
        tarjeta_data = {
            "cliente_id": cliente_id,
            "pan": "4532015112830366"  # Válida con Luhn
        }
        response = await client.post("/tarjetas/", json=tarjeta_data)
        assert response.status_code == 200
        data = response.json()
        assert data["pan_masked"] == "************0366"
        assert data["last4"] == "0366"


@pytest.mark.asyncio
async def test_crear_tarjeta_luhn_invalida():
    """Test rechazar tarjeta con Luhn inválido"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Crear cliente primero
        cliente_data = {
            "nombre": "Cliente Test Luhn",
            "email": "luhn@example.com",
            "telefono": "3002222222"
        }
        cliente_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = cliente_response.json()["id"]
        
        # Intentar crear tarjeta inválida
        tarjeta_data = {
            "cliente_id": cliente_id,
            "pan": "4532015112830367"  # Luhn inválido (último dígito cambiado)
        }
        response = await client.post("/tarjetas/", json=tarjeta_data)
        assert response.status_code == 400
        assert "Luhn" in response.json()["detail"]


@pytest.mark.asyncio
async def test_obtener_tarjeta():
    """Test obtener tarjeta por ID"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Setup
        cliente_data = {
            "nombre": "Cliente Obtener Tarjeta",
            "email": "obtener@example.com",
            "telefono": "3003333333"
        }
        cliente_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = cliente_response.json()["id"]
        
        tarjeta_data = {
            "cliente_id": cliente_id,
            "pan": "4532015112830366"
        }
        tarjeta_response = await client.post("/tarjetas/", json=tarjeta_data)
        tarjeta_id = tarjeta_response.json()["id"]
        
        # Get
        response = await client.get(f"/tarjetas/{tarjeta_id}")
        assert response.status_code == 200
        assert response.json()["last4"] == "0366"


# Tests para Cobros
@pytest.mark.asyncio
async def test_cobro_aprobado():
    """Test realizar cobro aprobado"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Setup
        cliente_data = {
            "nombre": "Cliente Cobro",
            "email": "cobro@example.com",
            "telefono": "3004444444"
        }
        cliente_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = cliente_response.json()["id"]
        
        tarjeta_data = {
            "cliente_id": cliente_id,
            "pan": "4532015112830366"
        }
        tarjeta_response = await client.post("/tarjetas/", json=tarjeta_data)
        tarjeta_id = tarjeta_response.json()["id"]
        
        # Crear cobro
        cobro_data = {
            "cliente_id": cliente_id,
            "tarjeta_id": tarjeta_id,
            "monto": 100.00
        }
        response = await client.post("/cobros/", json=cobro_data)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "approved"
        assert data["monto"] == 100.00


@pytest.mark.asyncio
async def test_historial_cobros():
    """Test obtener historial de cobros por cliente"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Setup
        cliente_data = {
            "nombre": "Cliente Historial",
            "email": "historial@example.com",
            "telefono": "3005555555"
        }
        cliente_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = cliente_response.json()["id"]
        
        tarjeta_data = {
            "cliente_id": cliente_id,
            "pan": "4532015112830366"
        }
        tarjeta_response = await client.post("/tarjetas/", json=tarjeta_data)
        tarjeta_id = tarjeta_response.json()["id"]
        
        # Crear múltiples cobros
        for i in range(3):
            cobro_data = {
                "cliente_id": cliente_id,
                "tarjeta_id": tarjeta_id,
                "monto": 50.00 + i
            }
            await client.post("/cobros/", json=cobro_data)
        
        # Obtener historial
        response = await client.get(f"/cobros/{cliente_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["total_cobros"] == 3


@pytest.mark.asyncio
async def test_reembolso_cobro():
    """Test reembolsar cobro aprobado"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Setup
        cliente_data = {
            "nombre": "Cliente Reembolso",
            "email": "reembolso@example.com",
            "telefono": "3006666666"
        }
        cliente_response = await client.post("/clientes/", json=cliente_data)
        cliente_id = cliente_response.json()["id"]
        
        tarjeta_data = {
            "cliente_id": cliente_id,
            "pan": "4532015112830366"
        }
        tarjeta_response = await client.post("/tarjetas/", json=tarjeta_data)
        tarjeta_id = tarjeta_response.json()["id"]
        
        # Crear cobro
        cobro_data = {
            "cliente_id": cliente_id,
            "tarjeta_id": tarjeta_id,
            "monto": 150.00
        }
        cobro_response = await client.post("/cobros/", json=cobro_data)
        cobro_id = cobro_response.json()["id"]
        
        # Reembolsar
        reembolso_data = {"motivo": "Cambio de opinión"}
        response = await client.post(f"/cobros/{cobro_id}/reembolso", json=reembolso_data)
        assert response.status_code == 200
        data = response.json()
        assert data["reembolsado"] == True
        assert data["fecha_reembolso"] is not None
