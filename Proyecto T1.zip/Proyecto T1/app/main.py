from fastapi import FastAPI
from app.database import connect_to_mongo, close_mongo_connection
from app.routers import clientes, tarjetas, cobros

app = FastAPI(
    title="API de Cobros Simulados",
    description="API REST para gestionar clientes, tarjetas de prueba y cobros simulados con validación Luhn",
    version="1.0.0"
)

# Routers
app.include_router(clientes.router)
app.include_router(tarjetas.router)
app.include_router(cobros.router)


@app.on_event("startup")
async def startup():
    """Conectar a MongoDB al iniciar"""
    await connect_to_mongo()


@app.on_event("shutdown")
async def shutdown():
    """Cerrar conexión a MongoDB al apagar"""
    await close_mongo_connection()


@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "ok",
        "mensaje": "API de Cobros Simulados",
        "docs": "/docs"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
