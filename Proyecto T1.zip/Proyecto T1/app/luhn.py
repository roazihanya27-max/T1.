"""
Módulo de validación y generación de números de tarjeta usando el algoritmo Luhn.
"""

def validate_luhn(card_number: str) -> bool:
    """
    Valida un número de tarjeta usando el algoritmo de Luhn.
    
    Args:
        card_number: String con el número de tarjeta (sin espacios)
        
    Returns:
        bool: True si es válido, False en caso contrario
    """
    if not card_number or not card_number.isdigit():
        return False
    
    digits = [int(d) for d in card_number]
    checksum = 0
    
    # Procesar de derecha a izquierda
    for i, digit in enumerate(reversed(digits)):
        if i % 2 == 1:  # Cada segundo dígito desde la derecha
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    
    return checksum % 10 == 0


def generate_card_number(bin_prefix: str = "424242", length: int = 16) -> str:
    """
    Genera un número de tarjeta válido con Luhn.
    
    Args:
        bin_prefix: BIN (Bank Identification Number) de inicio
        length: Longitud total del número de tarjeta
        
    Returns:
        str: Número de tarjeta válido
    """
    import random
    
    # Generar dígitos aleatorios
    digits = list(bin_prefix)
    while len(digits) < length - 1:
        digits.append(str(random.randint(0, 9)))
    
    # Calcular dígito de verificación
    checksum = 0
    for i, digit in enumerate(reversed(digits)):
        d = int(digit)
        if i % 2 == 0:  # Cada segundo dígito desde la derecha (0-indexado)
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    
    check_digit = (10 - (checksum % 10)) % 10
    return ''.join(digits) + str(check_digit)


def mask_card(card_number: str) -> str:
    """
    Enmascara un número de tarjeta dejando visibles solo los últimos 4 dígitos.
    
    Args:
        card_number: Número de tarjeta completo
        
    Returns:
        str: Tarjeta enmascarada ej. ************1234
    """
    if len(card_number) < 4:
        return card_number
    
    return "*" * (len(card_number) - 4) + card_number[-4:]


def get_last_four(card_number: str) -> str:
    """
    Obtiene los últimos 4 dígitos de una tarjeta.
    
    Args:
        card_number: Número de tarjeta completo
        
    Returns:
        str: Últimos 4 dígitos
    """
    return card_number[-4:]


def get_bin(card_number: str, length: int = 6) -> str:
    """
    Obtiene el BIN (Bank Identification Number) de una tarjeta.
    
    Args:
        card_number: Número de tarjeta completo
        length: Longitud del BIN (por defecto 6)
        
    Returns:
        str: BIN de la tarjeta
    """
    return card_number[:length]
