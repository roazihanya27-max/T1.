from fastapi import APIRouter, HTTPException, status
from bson import ObjectId
from datetime import datetime
from app.database import get_database
from app.schemas import TarjetaCreate, TarjetaUpdate, TarjetaResponse
from app.luhn import validate_luhn, mask_card, get_last_four, get_bin

router = APIRouter(prefix="/tarjetas", tags=["tarjetas"])


@router.post("/", response_model=TarjetaResponse)
async def crear_tarjeta(tarjeta: TarjetaCreate):
    """Registrar una tarjeta de prueba para un cliente"""
    db = get_database()
    
    # Validar que el cliente existe
    try:
        cliente_oid = ObjectId(tarjeta.cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de cliente inválido"
        )
    
    cliente = await db.clientes.find_one({"_id": cliente_oid})
    if not cliente:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cliente no encontrado"
        )
    
    # Validar número de tarjeta con Luhn
    pan_clean = tarjeta.pan.replace(" ", "").replace("-", "")
    if not pan_clean.isdigit() or len(pan_clean) < 13:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Número de tarjeta inválido (debe tener al menos 13 dígitos)"
        )
    
    if not validate_luhn(pan_clean):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Número de tarjeta no es válido (validación Luhn fallida)"
        )
    
    # Guardar solo la tarjeta enmascarada
    tarjeta_doc = {
        "cliente_id": tarjeta.cliente_id,
        "pan_masked": mask_card(pan_clean),
        "last4": get_last_four(pan_clean),
        "bin": get_bin(pan_clean),
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    
    result = await db.tarjetas.insert_one(tarjeta_doc)
    tarjeta_doc["_id"] = result.inserted_id
    
    return TarjetaResponse(**tarjeta_doc)


@router.get("/{tarjeta_id}", response_model=TarjetaResponse)
async def obtener_tarjeta(tarjeta_id: str):
    """Obtener una tarjeta por ID"""
    db = get_database()
    
    try:
        oid = ObjectId(tarjeta_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID inválido"
        )
    
    tarjeta = await db.tarjetas.find_one({"_id": oid})
    if not tarjeta:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tarjeta no encontrada"
        )
    
    return TarjetaResponse(**tarjeta)


@router.get("/cliente/{cliente_id}")
async def listar_tarjetas_cliente(cliente_id: str):
    """Listar todas las tarjetas de un cliente"""
    db = get_database()
    
    try:
        ObjectId(cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de cliente inválido"
        )
    
    tarjetas = await db.tarjetas.find({"cliente_id": cliente_id}).to_list(length=None)
    return [TarjetaResponse(**tarjeta) for tarjeta in tarjetas]


@router.put("/{tarjeta_id}", response_model=TarjetaResponse)
async def actualizar_tarjeta(tarjeta_id: str, tarjeta: TarjetaUpdate):
    """Actualizar metadatos de una tarjeta (no el PAN)"""
    db = get_database()
    
    try:
        oid = ObjectId(tarjeta_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID inválido"
        )
    
    existing = await db.tarjetas.find_one({"_id": oid})
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tarjeta no encontrada"
        )
    
    update_data = tarjeta.dict(exclude_unset=True)
    update_data["updated_at"] = datetime.utcnow()
    
    await db.tarjetas.update_one(
        {"_id": oid},
        {"$set": update_data}
    )
    
    updated = await db.tarjetas.find_one({"_id": oid})
    return TarjetaResponse(**updated)


@router.delete("/{tarjeta_id}", status_code=status.HTTP_204_NO_CONTENT)
async def eliminar_tarjeta(tarjeta_id: str):
    """Eliminar una tarjeta"""
    db = get_database()
    
    try:
        oid = ObjectId(tarjeta_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID inválido"
        )
    
    result = await db.tarjetas.delete_one({"_id": oid})
    
    if result.deleted_count == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tarjeta no encontrada"
        )
    
    # Eliminar también los cobros asociados
    await db.cobros.delete_many({"tarjeta_id": tarjeta_id})
