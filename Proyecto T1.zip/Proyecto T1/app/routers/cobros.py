from fastapi import APIRouter, HTTPException, status
from bson import ObjectId
from datetime import datetime
from typing import Optional
from app.database import get_database
from app.schemas import CobroCreate, CobroResponse, ReembolsoRequest

router = APIRouter(prefix="/cobros", tags=["cobros"])


async def evaluar_cobro(tarjeta_id: str) -> tuple[str, Optional[str]]:
    """
    Evalúa si un cobro debe ser aprobado o rechazado.
    
    Reglas de aprobación:
    - Si last4 termina en 0000: rechazar (tarjeta de prueba declinada)
    - Si monto es > 10000: rechazar (exceso de límite)
    - En otros casos: aprobar
    
    Returns:
        tuple: (status, codigo_motivo)
    """
    db = get_database()
    
    tarjeta = await db.tarjetas.find_one({"_id": ObjectId(tarjeta_id)})
    if not tarjeta:
        return "declined", "TARJETA_NO_ENCONTRADA"
    
    last4 = tarjeta["last4"]
    
    if last4 == "0000":
        return "declined", "TARJETA_RECHAZADA"
    
    return "approved", None


@router.post("/", response_model=CobroResponse)
async def crear_cobro(cobro: CobroCreate):
    """Realizar un cobro simulado"""
    db = get_database()
    
    # Validar cliente
    try:
        cliente_oid = ObjectId(cobro.cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de cliente inválido"
        )
    
    cliente = await db.clientes.find_one({"_id": cliente_oid})
    if not cliente:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cliente no encontrado"
        )
    
    # Validar tarjeta
    try:
        tarjeta_oid = ObjectId(cobro.tarjeta_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de tarjeta inválido"
        )
    
    tarjeta = await db.tarjetas.find_one({"_id": tarjeta_oid})
    if not tarjeta:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tarjeta no encontrada"
        )
    
    if tarjeta["cliente_id"] != cobro.cliente_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La tarjeta no pertenece al cliente"
        )
    
    # Evaluar cobro
    status_cobro, codigo_motivo = await evaluar_cobro(cobro.tarjeta_id)
    
    cobro_doc = {
        "cliente_id": cobro.cliente_id,
        "tarjeta_id": cobro.tarjeta_id,
        "monto": cobro.monto,
        "fecha_intento": datetime.utcnow(),
        "status": status_cobro,
        "codigo_motivo": codigo_motivo,
        "reembolsado": False,
        "fecha_reembolso": None
    }
    
    result = await db.cobros.insert_one(cobro_doc)
    cobro_doc["_id"] = result.inserted_id
    
    return CobroResponse(**cobro_doc)


@router.get("/{cliente_id}")
async def historial_cobros(cliente_id: str):
    """Obtener historial de cobros por cliente"""
    db = get_database()
    
    try:
        ObjectId(cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de cliente inválido"
        )
    
    cliente = await db.clientes.find_one({"_id": ObjectId(cliente_id)})
    if not cliente:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cliente no encontrado"
        )
    
    cobros = await db.cobros.find({"cliente_id": cliente_id}).to_list(length=None)
    
    return {
        "cliente_id": cliente_id,
        "total_cobros": len(cobros),
        "cobros": [CobroResponse(**cobro) for cobro in cobros]
    }


@router.get("/tarjeta/{tarjeta_id}")
async def historial_cobros_tarjeta(tarjeta_id: str):
    """Obtener historial de cobros por tarjeta"""
    db = get_database()
    
    try:
        ObjectId(tarjeta_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de tarjeta inválido"
        )
    
    tarjeta = await db.tarjetas.find_one({"_id": ObjectId(tarjeta_id)})
    if not tarjeta:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tarjeta no encontrada"
        )
    
    cobros = await db.cobros.find({"tarjeta_id": tarjeta_id}).to_list(length=None)
    
    return {
        "tarjeta_id": tarjeta_id,
        "pan_masked": tarjeta["pan_masked"],
        "total_cobros": len(cobros),
        "cobros": [CobroResponse(**cobro) for cobro in cobros]
    }


@router.post("/{cobro_id}/reembolso", response_model=CobroResponse)
async def reembolsar_cobro(cobro_id: str, reembolso: ReembolsoRequest):
    """Reembolsar un cobro previamente aprobado"""
    db = get_database()
    
    try:
        cobro_oid = ObjectId(cobro_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID de cobro inválido"
        )
    
    cobro = await db.cobros.find_one({"_id": cobro_oid})
    if not cobro:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cobro no encontrado"
        )
    
    if cobro["status"] != "approved":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Solo se pueden reembolsar cobros aprobados"
        )
    
    if cobro["reembolsado"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Este cobro ya ha sido reembolsado"
        )
    
    # Actualizar cobro
    await db.cobros.update_one(
        {"_id": cobro_oid},
        {
            "$set": {
                "reembolsado": True,
                "fecha_reembolso": datetime.utcnow()
            }
        }
    )
    
    updated = await db.cobros.find_one({"_id": cobro_oid})
    return CobroResponse(**updated)
