from fastapi import APIRouter, HTTPException, status
from bson import ObjectId
from datetime import datetime
from app.database import get_database
from app.schemas import ClienteCreate, ClienteUpdate, ClienteResponse

router = APIRouter(prefix="/clientes", tags=["clientes"])


@router.post("/", response_model=ClienteResponse)
async def crear_cliente(cliente: ClienteCreate):
    """Crear un nuevo cliente"""
    db = get_database()
    
    # Verificar si el email ya existe
    existing = await db.clientes.find_one({"email": cliente.email})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El email ya está registrado"
        )
    
    cliente_doc = {
        "nombre": cliente.nombre,
        "email": cliente.email,
        "telefono": cliente.telefono,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    
    result = await db.clientes.insert_one(cliente_doc)
    cliente_doc["_id"] = result.inserted_id
    
    return ClienteResponse(**cliente_doc)


@router.get("/{cliente_id}", response_model=ClienteResponse)
async def obtener_cliente(cliente_id: str):
    """Obtener un cliente por ID"""
    db = get_database()
    
    try:
        oid = ObjectId(cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID inválido"
        )
    
    cliente = await db.clientes.find_one({"_id": oid})
    if not cliente:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cliente no encontrado"
        )
    
    return ClienteResponse(**cliente)


@router.get("/", response_model=list[ClienteResponse])
async def listar_clientes():
    """Listar todos los clientes"""
    db = get_database()
    
    clientes = await db.clientes.find().to_list(length=None)
    return [ClienteResponse(**cliente) for cliente in clientes]


@router.put("/{cliente_id}", response_model=ClienteResponse)
async def actualizar_cliente(cliente_id: str, cliente: ClienteUpdate):
    """Actualizar un cliente"""
    db = get_database()
    
    try:
        oid = ObjectId(cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID inválido"
        )
    
    # Verificar que existe
    existing = await db.clientes.find_one({"_id": oid})
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cliente no encontrado"
        )
    
    # Si se actualiza el email, verificar que no esté en uso
    if cliente.email and cliente.email != existing["email"]:
        email_exists = await db.clientes.find_one({"email": cliente.email})
        if email_exists:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El email ya está registrado"
            )
    
    update_data = cliente.dict(exclude_unset=True)
    update_data["updated_at"] = datetime.utcnow()
    
    await db.clientes.update_one(
        {"_id": oid},
        {"$set": update_data}
    )
    
    updated = await db.clientes.find_one({"_id": oid})
    return ClienteResponse(**updated)


@router.delete("/{cliente_id}", status_code=status.HTTP_204_NO_CONTENT)
async def eliminar_cliente(cliente_id: str):
    """Eliminar un cliente"""
    db = get_database()
    
    try:
        oid = ObjectId(cliente_id)
    except:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="ID inválido"
        )
    
    result = await db.clientes.delete_one({"_id": oid})
    
    if result.deleted_count == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cliente no encontrado"
        )
    
    # Eliminar también sus tarjetas y cobros
    await db.tarjetas.delete_many({"cliente_id": cliente_id})
    await db.cobros.delete_many({"cliente_id": cliente_id})
