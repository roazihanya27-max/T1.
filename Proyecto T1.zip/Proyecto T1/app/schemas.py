from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime


class ClienteCreate(BaseModel):
    nombre: str = Field(..., min_length=1)
    email: EmailStr
    telefono: str = Field(..., min_length=7)


class ClienteUpdate(BaseModel):
    nombre: Optional[str] = None
    email: Optional[EmailStr] = None
    telefono: Optional[str] = None


class ClienteResponse(BaseModel):
    id: str = Field(alias="_id")
    nombre: str
    email: str
    telefono: str
    created_at: datetime
    updated_at: datetime

    class Config:
        populate_by_name = True


class TarjetaCreate(BaseModel):
    cliente_id: str
    pan: str = Field(..., description="Número completo de tarjeta (para validación)")


class TarjetaUpdate(BaseModel):
    nombre: Optional[str] = None


class TarjetaResponse(BaseModel):
    id: str = Field(alias="_id")
    cliente_id: str
    pan_masked: str
    last4: str
    bin: str
    created_at: datetime
    updated_at: datetime

    class Config:
        populate_by_name = True


class CobroCreate(BaseModel):
    cliente_id: str
    tarjeta_id: str
    monto: float = Field(..., gt=0)


class CobroResponse(BaseModel):
    id: str = Field(alias="_id")
    cliente_id: str
    tarjeta_id: str
    monto: float
    fecha_intento: datetime
    status: str
    codigo_motivo: Optional[str] = None
    reembolsado: bool
    fecha_reembolso: Optional[datetime] = None

    class Config:
        populate_by_name = True


class ReembolsoRequest(BaseModel):
    motivo: Optional[str] = None
