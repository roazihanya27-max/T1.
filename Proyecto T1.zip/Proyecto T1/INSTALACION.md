# Guía de Instalación - API de Cobros Simulados

## Requisitos Previos

- Python 3.11 o superior
- MongoDB 4.0 o superior
- Git (opcional, para clonar el repositorio)

## Opción 1: Docker (Recomendado)

Esta es la opción más fácil si tienes Docker instalado.

### Pasos:

1. **Navega a la carpeta del proyecto:**
   ```powershell
   cd C:\ruta\a\Proyecto T1
   ```

2. **Levanta los servicios con Docker Compose:**
   ```powershell
   docker-compose up
   ```

3. **Espera a que aparezca:**
   ```
   API is running on http://0.0.0.0:8000
   ```

4. **Accede a la documentación interactiva:**
   - Abre tu navegador en: `http://localhost:8000/docs`

5. **Para detener:**
   ```powershell
   docker-compose down
   ```

---

## Opción 2: Instalación Manual en Windows

Si prefieres ejecutar sin Docker.

### Paso 1: Crear Entorno Virtual

```powershell
# En PowerShell, navega al proyecto
cd E:\Proyecto T1

# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
venv\Scripts\Activate.ps1

# Si aparece un error de permisos, ejecuta:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Paso 2: Instalar Dependencias

```powershell
# Asegúrate que estás en el entorno virtual (deberías ver "venv" en el prompt)
pip install --upgrade pip
pip install -r requirements.txt
```

### Paso 3: Configurar MongoDB

**Opción A: Usar MongoDB local (instalado en tu PC)**

1. Asegúrate que MongoDB está corriendo (puerto 27017 por defecto)
2. Crea el archivo `.env`:
   ```powershell
   copy .env.example .env
   ```

**Opción B: Usar MongoDB con Docker (sin instalar MongoDB en tu PC)**

```powershell
# En otra terminal PowerShell
docker run -d -p 27017:27017 --name mongo -e MONGO_INITDB_ROOT_USERNAME=root -e MONGO_INITDB_ROOT_PASSWORD=password mongo:7.0
```

Luego edita `.env` y cambia:
```
MONGODB_URL=mongodb://root:password@localhost:27017/cobros_db?authSource=admin
```

### Paso 4: Ejecutar la API

```powershell
# Asegúrate que el entorno virtual está activo
uvicorn app.main:app --reload
```

Deberías ver algo como:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Application startup complete
```

### Paso 5: Acceder a la API

- **Swagger UI (Documentación interactiva):** `http://localhost:8000/docs`
- **ReDoc (Documentación alternativa):** `http://localhost:8000/redoc`
- **Health check:** `http://localhost:8000/`

---

## Verificar que Todo Funciona

### Opción A: Usar Swagger UI

1. Abre `http://localhost:8000/docs`
2. Expande el endpoint `POST /clientes/`
3. Haz click en "Try it out"
4. Completa el formulario con:
   ```json
   {
     "nombre": "Test User",
     "email": "test@example.com",
     "telefono": "3001234567"
   }
   ```
5. Presiona "Execute"
6. Deberías ver una respuesta 200 con los datos del cliente creado

### Opción B: Usar PowerShell con curl

```powershell
# Crear cliente
$cliente = @{
    nombre = "Juan Pérez"
    email = "juan@example.com"
    telefono = "3001234567"
} | ConvertTo-Json

curl -X POST http://localhost:8000/clientes/ `
  -ContentType "application/json" `
  -Body $cliente
```

---

## Ejecutar Tests

```powershell
# Asegúrate que el entorno virtual está activo

# Todos los tests
pytest

# Tests con output detallado
pytest -v

# Solo tests de Luhn
pytest tests/test_luhn.py -v

# Con cobertura
pytest --cov=app tests/
```

---

## Estructura del Proyecto Explicada

```
Proyecto T1/
├── app/                          # Código principal de la API
│   ├── main.py                   # Aplicación FastAPI
│   ├── config.py                 # Configuración (variables de entorno)
│   ├── database.py               # Conexión a MongoDB
│   ├── luhn.py                   # Validación Luhn + generación de tarjetas
│   ├── schemas.py                # Modelos de datos (Pydantic)
│   └── routers/                  # Endpoints de la API
│       ├── clientes.py           # CRUD de clientes
│       ├── tarjetas.py           # CRUD de tarjetas
│       └── cobros.py             # Cobros y reembolsos
│
├── tests/                        # Tests unitarios e integración
│   ├── test_luhn.py             # Tests para validación Luhn
│   ├── test_api.py              # Tests de endpoints
│   └── conftest.py              # Configuración de pytest
│
├── docs/                         # Documentación
│   ├── TEST_CARDS.md            # Tarjetas de prueba documentadas
│   └── EJEMPLOS.py              # Ejemplos de code
│
├── .env.example                  # Ejemplo de variables (copiar como .env)
├── .gitignore                    # Archivos a ignorar en git
├── requirements.txt              # Dependencias Python
├── Dockerfile                    # Para crear imagen Docker
├── docker-compose.yml            # Para levantar MongoDB + API
├── README.md                     # Documentación principal
└── INSTALACION.md                # Este archivo
```

---

## Solución de Problemas

### 1. Error: "ModuleNotFoundError: No module named 'fastapi'"

**Solución:**
```powershell
# Verifica que el venv esté activo (debe tener "venv" en el prompt)
# Si no está activo, ejecuta:
venv\Scripts\Activate.ps1

# Luego instala dependencias:
pip install -r requirements.txt
```

### 2. Error: "Connection refused" para MongoDB

**Solución:**

MongoDB no está corriendo. Elige una:

**A) Levantar MongoDB con Docker:**
```powershell
docker run -d -p 27017:27017 --name cobros-mongo mongo:7.0
```

**B) Si tiene MongoDB instalado localmente, inicia el servicio:**
```powershell
# Windows
net start MongoDB
# O busca MongoDB Community Edition en servicios
```

**C) Verifica que la conexión es correcta en `.env`:
```
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=cobros_db
```

### 3. Error: "Port 8000 already in use"

Algo más está usando el puerto 8000. Opciones:

```powershell
# Opción A: Cambiar a otro puerto
uvicorn app.main:app --reload --port 8001

# Opción B: Encontrar y matar el proceso en puerto 8000
# En PowerShell (como admin):
Get-Process | Where-Object {$_.Name -like "*python*"} | Stop-Process
```

### 4. Error con permisos de ejecución en PowerShell

```powershell
# Ejecuta como admin:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## Próximos Pasos

1. **Crear un cliente:** Consulta la sección "Verificar que Todo Funciona"
2. **Registrar una tarjeta:** Usa una de las tarjetas de prueba documentadas
3. **Realizar un cobro:** La API rechazará o aprobará según las reglas
4. **Ver historial:** Consulta todos los cobros de un cliente

Para más detalles, ver [README.md](README.md)

---

**Última actualización:** 2026-02-10
