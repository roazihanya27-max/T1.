# API de Cobros Simulados - T1Pagos

API REST completa para gestionar clientes, tarjetas de prueba y cobros simulados con validación Luhn, incluyendo soporte para reembolsos.

## Características

✅ **CRUD Completo**
- Gestión de clientes (crear, leer, actualizar, eliminar)
- Gestión de tarjetas de prueba (crear, leer, actualizar, eliminar)
- Cobros simulados con aprobación/rechazo configurable
- Reembolsos de cobros aprobados

✅ **Validación Luhn**
- Validación de números de tarjeta con algoritmo Luhn
- Generación automática de tarjetas válidas
- Pruebas unitarias completas

✅ **Seguridad**
- No se almacenan números completos de tarjeta (PAN)
- Solo se almacenan: PAN enmascarado, últimos 4 dígitos, BIN
- Encapsulación de datos sensibles

✅ **Documentación**
- OpenAPI/Swagger integrado
- Ejemplos de requests
- Documentación de tarjetas de prueba

## Requisitos

- Python 3.11+
- MongoDB 4.0+
- Docker (opcional)

## Instalación

### Opción 1: Docker (Recomendado)

```bash
docker-compose up
```

Esto levanta:
- MongoDB en puerto 27017
- API en puerto 8000

### Opción 2: Instalación Manual

```bash
# Clonar/descargar el proyecto
cd api-cobros-t1

# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
# En Windows:
venv\Scripts\activate
# En Linux/Mac:
source venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt

# Crear archivo .env
cp .env.example .env

# Asegurar que MongoDB está corriendo (default: localhost:27017)

# Ejecutar la aplicación
uvicorn app.main:app --reload
```

## Uso

### Swagger UI (Interactive Documentation)

Una vez la API está corriendo, accede a:
```
http://localhost:8000/docs
```

### Ejemplos de Requests

#### 1. Crear Cliente

```bash
curl -X POST http://localhost:8000/clientes/ \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "telefono": "3001234567"
  }'
```

**Respuesta:**
```json
{
  "id": "507f1f77bcf86cd799439011",
  "nombre": "Juan Pérez",
  "email": "juan@example.com",
  "telefono": "3001234567",
  "created_at": "2026-02-10T10:00:00",
  "updated_at": "2026-02-10T10:00:00"
}
```

#### 2. Registrar Tarjeta de Prueba

```bash
curl -X POST http://localhost:8000/tarjetas/ \
  -H "Content-Type: application/json" \
  -d '{
    "cliente_id": "507f1f77bcf86cd799439011",
    "pan": "4532015112830366"
  }'
```

**Respuesta:**
```json
{
  "id": "507f1f77bcf86cd799439012",
  "cliente_id": "507f1f77bcf86cd799439011",
  "pan_masked": "************0366",
  "last4": "0366",
  "bin": "453201",
  "created_at": "2026-02-10T10:05:00",
  "updated_at": "2026-02-10T10:05:00"
}
```

#### 3. Realizar Cobro

```bash
curl -X POST http://localhost:8000/cobros/ \
  -H "Content-Type: application/json" \
  -d '{
    "cliente_id": "507f1f77bcf86cd799439011",
    "tarjeta_id": "507f1f77bcf86cd799439012",
    "monto": 150.50
  }'
```

**Respuesta (Aprobado):**
```json
{
  "id": "507f1f77bcf86cd799439013",
  "cliente_id": "507f1f77bcf86cd799439011",
  "tarjeta_id": "507f1f77bcf86cd799439012",
  "monto": 150.50,
  "fecha_intento": "2026-02-10T10:10:00",
  "status": "approved",
  "codigo_motivo": null,
  "reembolsado": false,
  "fecha_reembolso": null
}
```

#### 4. Obtener Historial de Cobros

```bash
curl -X GET http://localhost:8000/cobros/507f1f77bcf86cd799439011
```

**Respuesta:**
```json
{
  "cliente_id": "507f1f77bcf86cd799439011",
  "total_cobros": 1,
  "cobros": [
    {
      "id": "507f1f77bcf86cd799439013",
      "cliente_id": "507f1f77bcf86cd799439011",
      "tarjeta_id": "507f1f77bcf86cd799439012",
      "monto": 150.50,
      "fecha_intento": "2026-02-10T10:10:00",
      "status": "approved",
      "codigo_motivo": null,
      "reembolsado": false,
      "fecha_reembolso": null
    }
  ]
}
```

#### 5. Reembolsar Cobro

```bash
curl -X POST http://localhost:8000/cobros/507f1f77bcf86cd799439013/reembolso \
  -H "Content-Type: application/json" \
  -d '{
    "motivo": "Cambio de opinión del cliente"
  }'
```

**Respuesta:**
```json
{
  "id": "507f1f77bcf86cd799439013",
  "cliente_id": "507f1f77bcf86cd799439011",
  "tarjeta_id": "507f1f77bcf86cd799439012",
  "monto": 150.50,
  "fecha_intento": "2026-02-10T10:10:00",
  "status": "approved",
  "codigo_motivo": null,
  "reembolsado": true,
  "fecha_reembolso": "2026-02-10T10:15:00"
}
```

## Endpoints

### Clientes
- `POST /clientes/` - Crear cliente
- `GET /clientes/{cliente_id}` - Obtener cliente
- `GET /clientes/` - Listar clientes
- `PUT /clientes/{cliente_id}` - Actualizar cliente
- `DELETE /clientes/{cliente_id}` - Eliminar cliente

### Tarjetas
- `POST /tarjetas/` - Registrar tarjeta (con validación Luhn)
- `GET /tarjetas/{tarjeta_id}` - Obtener tarjeta
- `GET /tarjetas/cliente/{cliente_id}` - Listar tarjetas de un cliente
- `PUT /tarjetas/{tarjeta_id}` - Actualizar tarjeta
- `DELETE /tarjetas/{tarjeta_id}` - Eliminar tarjeta

### Cobros
- `POST /cobros/` - Realizar cobro simulado
- `GET /cobros/{cliente_id}` - Historial de cobros por cliente
- `GET /cobros/tarjeta/{tarjeta_id}` - Historial de cobros por tarjeta
- `POST /cobros/{cobro_id}/reembolso` - Reembolsar cobro

## Reglas de Aprobación/Rechazo

Un cobro es **APROBADO** si:
- La tarjeta es válida (pasó validación Luhn al registrarse)
- El último dígito de la tarjeta NO es 0000
- El cliente existe

Un cobro es **RECHAZADO** si:
- La tarjeta tiene last4 = 0000 (código: `TARJETA_RECHAZADA`)
- La tarjeta no existe (código: `TARJETA_NO_ENCONTRADA`)

Ver [Tarjetas de Prueba](docs/TEST_CARDS.md) para detalles completos.

## Tarjetas de Prueba

### Tarjetas Preconfiguradas

**Tarjeta Aprobada (Visa):**
- PAN: `4532015112830366`
- Last4: `0366`
- BIN: `453201`

**Tarjeta Aprobada (Mastercard):**
- PAN: `5425233010103442`
- Last4: `3442`
- BIN: `542523`

**Tarjeta Aprobada (American Express):**
- PAN: `378282246310005`
- Last4: `0005`
- BIN: `378282`

Ver [Documentación Completa de Tarjetas](docs/TEST_CARDS.md).

## Pruebas

### Ejecutar Tests Unitarios

```bash
# Todas las pruebas
pytest

# Con coverage
pytest --cov=app tests/

# Tests específicos
pytest tests/test_luhn.py -v
pytest tests/test_api.py -v
```

### Cobertura de Pruebas

✅ Validación Luhn (generación, validación, enmascaramiento)
✅ CRUD de clientes (crear, leer, actualizar, eliminar)
✅ CRUD de tarjetas con validación Luhn
✅ Cobros aprobados y rechazados
✅ Reembolsos
✅ Historial de cobros

## Estructura del Proyecto

```
api-cobros-t1/
├── app/
│   ├── __init__.py
│   ├── main.py                 # Aplicación principal
│   ├── config.py               # Configuración
│   ├── database.py             # Conexión a MongoDB
│   ├── luhn.py                 # Validación y generación Luhn
│   ├── schemas.py              # Modelos Pydantic
│   └── routers/
│       ├── __init__.py
│       ├── clientes.py         # Endpoints de clientes
│       ├── tarjetas.py         # Endpoints de tarjetas
│       └── cobros.py           # Endpoints de cobros
├── tests/
│   ├── __init__.py
│   ├── test_luhn.py           # Tests de Luhn
│   └── test_api.py            # Tests de API
├── docs/
│   └── TEST_CARDS.md          # Documentación de tarjetas
├── .env.example               # Archivo de ejemplo para variables
├── requirements.txt           # Dependencias Python
├── Dockerfile                 # Para Docker
├── docker-compose.yml         # Compose para MongoDB + API
└── README.md                  # Este archivo
```

## Variables de Entorno

```
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=cobros_db
DEBUG=True
```

Para autenticación en MongoDB (Docker):
```
MONGODB_URL=mongodb://root:password@localhost:27017/cobros_db?authSource=admin
```

## Modelado MongoDB

### Colecciones

#### clientes
```json
{
  "_id": ObjectId,
  "nombre": "string",
  "email": "string",
  "telefono": "string",
  "created_at": DateTime,
  "updated_at": DateTime
}
```

#### tarjetas
```json
{
  "_id": ObjectId,
  "cliente_id": "string",
  "pan_masked": "string",      // ej. ************1234
  "last4": "string",           // ej. 1234
  "bin": "string",             // ej. 453201
  "created_at": DateTime,
  "updated_at": DateTime
}
```

#### cobros
```json
{
  "_id": ObjectId,
  "cliente_id": "string",
  "tarjeta_id": "string",
  "monto": float,
  "fecha_intento": DateTime,
  "status": "approved|declined",
  "codigo_motivo": "string|null",     // null si aprobado
  "reembolsado": boolean,
  "fecha_reembolso": "DateTime|null"
}
```

## Seguridad

🔒 **Medidas de Seguridad Implementadas:**

1. **No se almacenan PANs completos** - Solo pan_masked, last4, bin
2. **Validación Luhn obligatoria** - Antes de registrar una tarjeta
3. **Enmascaramiento de datos** - ej. ************1234
4. **Validación de entrada** - Usando Pydantic
5. **Control de acceso lógico** - Verificación de pertenencia de tarjetas

## Validación Luhn

La API implementa el algoritmo Luhn completo:

```python
def validate_luhn(card_number: str) -> bool:
    """Valida un número de tarjeta con el algoritmo de Luhn"""
    digits = [int(d) for d in card_number]
    checksum = 0
    
    for i, digit in enumerate(reversed(digits)):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    
    return checksum % 10 == 0
```

Todas las tarjetas registradas DEBEN ser válidas según Luhn.

## Solución de Problemas

### Error: "Connection refused" a MongoDB

Asegúrate de que MongoDB está corriendo:
```bash
# Con Docker Compose (recomendado):
docker-compose up

# O manualmente, MongoDB debe estar en localhost:27017
```

### Error: "Database not connected"

Verifica la variable `MONGODB_URL` en el archivo `.env`

### Tests fallan

```bash
# Instalar las dependencias de test
pip install pytest pytest-asyncio

# Ejecutar tests
pytest -v
```

## Criterios de Evaluación Cumplidos

✅ **Funcionalidad mínima:** CRUD clientes/tarjetas, cobros simulados y reembolsos  
✅ **Implementación Luhn:** Validación y tests unitarios  
✅ **Modelado Mongo:** Estructura correcta con enmascaramiento  
✅ **Claridad de código:** Bien documentado y estructurado  
✅ **Extras:** Docker, Swagger/OpenAPI, manejo de errores, endpoints idempotentes  

## Contacto y Soporte

Para reportar issues o sugerencias, crear un issue en el repositorio.

## Licencia

MIT

---

**Última actualización:** 2026-02-10  
**Versión:** 1.0.0
