# Tarjetas de Prueba Documentadas

Este documento describe las tarjetas de prueba usadas en la API con sus reglas de aprobación/rechazo.

## Tarjetas de Prueba Válidas

### 1. Visa - Aprobada
- **Last4:** 0366
- **BIN:** 453201
- **Número Enmascarado:** ************0366
- **Regla de Aprobación:** Aprobado por defecto
- **Monto Límite:** Sin límite específico
- **Descripción:** Tarjeta Visa de prueba válida que siempre será aprobada

### 2. Discover - Aprobada
- **Last4:** 9424
- **BIN:** 601100
- **Número Enmascarado:** ************9424
- **Regla de Aprobación:** Aprobado por defecto
- **Monto Límite:** Sin límite específico
- **Descripción:** Tarjeta Discover de prueba válida

### 3. American Express - Aprobada
- **Last4:** 0005
- **BIN:** 378282
- **Número Enmascarado:** ****0005
- **Regla de Aprobación:** Aprobado por defecto
- **Monto Límite:** Sin límite específico
- **Descripción:** Tarjeta American Express de prueba válida (15 dígitos)

## Reglas de Aprobación/Rechazo

### Aprobado (Approved)
✅ Cualquier tarjeta válida (que pase validación Luhn)
- Monto normal
- Last4 diferente de 0000
- Cliente válido

### Rechazado (Declined)
❌ Los siguientes escenarios:

1. **Last4 = 0000**
   - Código: `TARJETA_RECHAZADA`
   - Descripción: Tarjeta de prueba configurada para rechazar

2. **Tarjeta no encontrada**
   - Código: `TARJETA_NO_ENCONTRADA`
   - Descripción: La tarjeta no existe en la base de datos

## Números Completos para Pruebas

⚠️ **ADVERTENCIA:** Los siguientes números se proporcionan SOLO para pruebas internas y desarrollo. 
No usar en entornos de producción.

```
Visa válida:              4532015112830366
Mastercard válida:        5425233010103442
American Express válida:  378282246310005
```

## Cómo Registrar una Tarjeta

```bash
curl -X POST http://localhost:8000/tarjetas/ \
  -H "Content-Type: application/json" \
  -d '{
    "cliente_id": "YOUR_CLIENTE_ID",
    "pan": "4532015112830366"
  }'
```

## Historial de Cambios

- **v1.0** (2026-02-10): Creación de reglas iniciales de aprobación/rechazo
