"""
Colección de ejemplos de requests en formato Python para testing.
"""

# Ejemplos para usar con requests library o directamente en tests

CLIENTE_EJEMPLO = {
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "telefono": "3001234567"
}

TARJETA_VISA = {
    "cliente_id": "507f1f77bcf86cd799439011",  # Reemplazar con ID real
    "pan": "4532015112830366"
}

TARJETA_MASTERCARD = {
    "cliente_id": "507f1f77bcf86cd799439011",  # Reemplazar con ID real
    "pan": "5425233010103442"
}

TARJETA_AMEX = {
    "cliente_id": "507f1f77bcf86cd799439011",  # Reemplazar con ID real
    "pan": "378282246310005"
}

COBRO_EJEMPLO = {
    "cliente_id": "507f1f77bcf86cd799439011",
    "tarjeta_id": "507f1f77bcf86cd799439012",
    "monto": 150.50
}

REEMBOLSO_EJEMPLO = {
    "motivo": "Cambio de opinión del cliente"
}

# Ejemplo de uso con requests library:
"""
import requests

BASE_URL = "http://localhost:8000"

# Crear cliente
response = requests.post(f"{BASE_URL}/clientes/", json=CLIENTE_EJEMPLO)
cliente_id = response.json()["id"]

# Registrar tarjeta
TARJETA_VISA["cliente_id"] = cliente_id
response = requests.post(f"{BASE_URL}/tarjetas/", json=TARJETA_VISA)
tarjeta_id = response.json()["id"]

# Realizar cobro
COBRO_EJEMPLO["cliente_id"] = cliente_id
COBRO_EJEMPLO["tarjeta_id"] = tarjeta_id
response = requests.post(f"{BASE_URL}/cobros/", json=COBRO_EJEMPLO)
cobro_id = response.json()["id"]

# Obtener historial
response = requests.get(f"{BASE_URL}/cobros/{cliente_id}")
print(response.json())

# Reembolsar
response = requests.post(f"{BASE_URL}/cobros/{cobro_id}/reembolso", json=REEMBOLSO_EJEMPLO)
print(response.json())
"""
